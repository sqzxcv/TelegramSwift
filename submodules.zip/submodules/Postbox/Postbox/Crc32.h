#ifndef Postbox_Crc32_h
#define Postbox_Crc32_h

#import <Foundation/Foundation.h>

uint32_t Crc32(const void *bytes, int length);

#endif
