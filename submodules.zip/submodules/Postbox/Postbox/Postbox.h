//
//  Postbox.h
//  Postbox
//
//  Created by Peter on 10/06/15.
//  Copyright (c) 2015 Telegram. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Postbox.
FOUNDATION_EXPORT double PostboxVersionNumber;

//! Project version string for Postbox.
FOUNDATION_EXPORT const unsigned char PostboxVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Postbox/PublicHeader.h>

#import <Postbox/MurMurHash32.h>
#import <Postbox/IpcNotifier.h>
