#import <Foundation/Foundation.h>

@protocol SDisposable <NSObject>

- (void)dispose;

@end
