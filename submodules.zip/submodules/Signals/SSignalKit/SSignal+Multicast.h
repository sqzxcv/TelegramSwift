#import <SSignalKit/SSignal.h>

@interface SSignal (Multicast)

- (SSignal *)multicast;

@end
