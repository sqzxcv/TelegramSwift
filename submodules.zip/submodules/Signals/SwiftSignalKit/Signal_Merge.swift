import Foundation

/*public func merge<T, E>(signal1: Signal<T, E>, signal2: Signal<T, E>) -> Signal<T, E> {
    return Signal { subscriber in
        
    }
}*/
