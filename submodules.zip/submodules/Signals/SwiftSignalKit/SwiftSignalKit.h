//
//  SwiftSignalKit.h
//  SwiftSignalKit
//
//  Created by Peter on 10/06/15.
//  Copyright (c) 2015 Telegram. All rights reserved.
//

#if __IPHONE_OS_VERSION_MIN_REQUIRED
#import <UIKit/UIKit.h>
#else
#import <Foundation/Foundation.h>
#endif

//! Project version number for SwiftSignalKit.
FOUNDATION_EXPORT double SwiftSignalKitVersionNumber;

//! Project version string for SwiftSignalKit.
FOUNDATION_EXPORT const unsigned char SwiftSignalKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftSignalKit/PublicHeader.h>


