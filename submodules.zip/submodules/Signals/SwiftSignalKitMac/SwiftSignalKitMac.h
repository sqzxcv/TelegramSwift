//
//  SwiftSignalKitMac.h
//  SwiftSignalKitMac
//
//  Created by Peter on 9/5/16.
//  Copyright © 2016 Telegram. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SwiftSignalKitMac.
FOUNDATION_EXPORT double SwiftSignalKitMacVersionNumber;

//! Project version string for SwiftSignalKitMac.
FOUNDATION_EXPORT const unsigned char SwiftSignalKitMacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftSignalKitMac/PublicHeader.h>


