import Foundation

public final class GlobalTelegramCoreConfiguration {
    public static var readMessages: Bool = true
}
