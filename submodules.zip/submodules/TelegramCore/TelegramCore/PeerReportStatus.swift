import Foundation

public enum PeerReportStatus: Int32 {
    case unknown
    case none
    case canReport
    case didReport
}
