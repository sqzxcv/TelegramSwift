//
//  TelegramCore.h
//  TelegramCore
//
//  Created by Peter on 8/1/16.
//  Copyright © 2016 Peter. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TelegramCore.
FOUNDATION_EXPORT double TelegramCoreVersionNumber;

//! Project version string for TelegramCore.
FOUNDATION_EXPORT const unsigned char TelegramCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TelegramCore/PublicHeader.h>
